Iconset: User Pictures (https://www.iconfinder.com/iconsets/user-pictures)
Author: Anna Litviniuk (https://www.iconfinder.com/Naf_Naf)
License: Free for commercial use ()
Download date: 2023-11-16